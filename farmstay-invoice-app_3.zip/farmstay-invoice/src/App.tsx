import { useEffect, useState } from 'react'
import { seedIfNeeded, getSettings, getInvoices, getClients, getItems } from './lib/storage'
import type { Invoice, Client, Item, AppSettings } from './types'
import Dashboard from './pages/Dashboard'
import InvoiceList from './pages/InvoiceList'
import InvoiceEditor from './pages/InvoiceEditor'
import ClientsPage from './pages/ClientsPage'
import ItemsPage from './pages/ItemsPage'
import SettingsPage from './pages/SettingsPage'

type Page = 'dashboard' | 'invoices' | 'create' | 'edit' | 'clients' | 'items' | 'settings'

export default function App() {
  const [page, setPage] = useState<Page>('dashboard')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [settings, setSettings] = useState<AppSettings | null>(null)
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [clients, setClients] = useState<Client[]>([])
  const [items, setItems] = useState<Item[]>([])
  const [ready, setReady] = useState(false)

  const refresh = () => {
    setSettings(getSettings())
    setInvoices(getInvoices())
    setClients(getClients())
    setItems(getItems())
  }

  useEffect(() => {
    seedIfNeeded().then(() => {
      refresh()
      setReady(true)
    })
  }, [])

  const navigate = (p: Page, id?: string) => {
    setPage(p)
    setEditingId(id || null)
  }

  if (!ready || !settings) {
    return (
      <div style={{ display: 'grid', placeItems: 'center', height: '100%', color: '#5c6b66' }}>
        Loading FarmStay Invoice…
      </div>
    )
  }

  const navItems: { id: Page; label: string; icon: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'invoices', label: 'Invoices', icon: '🧾' },
    { id: 'create', label: 'New Invoice', icon: '➕' },
    { id: 'clients', label: 'Clients', icon: '👥' },
    { id: 'items', label: 'Items', icon: '🧺' },
    { id: 'settings', label: 'Settings', icon: '⚙️' },
  ]

  return (
    <div className="app-shell">
      <header className="mobile-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <div className="sidebar-logo" style={{ width: 32, height: 32, fontSize: '0.75rem' }}>SUGI</div>
          <strong>FarmStay Invoice</strong>
        </div>
        <button className="btn btn-sm" style={{ background: 'rgba(255,255,255,0.15)', color: 'white' }}
          onClick={() => navigate('create')}>
          + New
        </button>
      </header>

      <nav className="mobile-nav">
        {navItems.map(n => (
          <button key={n.id} className={page === n.id || (page === 'edit' && n.id === 'invoices') ? 'active' : ''}
            onClick={() => navigate(n.id)}>
            {n.label}
          </button>
        ))}
      </nav>

      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="sidebar-logo">SUGI</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: '0.95rem' }}>FarmStay</div>
            <div style={{ fontSize: '0.75rem', opacity: 0.7 }}>Invoice Maker</div>
          </div>
        </div>
        <nav>
          {navItems.map(n => (
            <button key={n.id}
              className={`nav-item ${page === n.id || (page === 'edit' && n.id === 'invoices') ? 'active' : ''}`}
              onClick={() => navigate(n.id)}>
              <span>{n.icon}</span>
              <span>{n.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      <main className="main-content">
        {page === 'dashboard' && (
          <Dashboard
            settings={settings}
            invoices={invoices}
            clients={clients}
            onNavigate={navigate}
          />
        )}
        {page === 'invoices' && (
          <InvoiceList
            invoices={invoices}
            onEdit={(id) => navigate('edit', id)}
            onCreate={() => navigate('create')}
            onRefresh={refresh}
          />
        )}
        {(page === 'create' || page === 'edit') && (
          <InvoiceEditor
            invoiceId={editingId}
            settings={settings}
            clients={clients}
            items={items}
            onSave={() => { refresh(); navigate('invoices') }}
            onCancel={() => navigate('invoices')}
            onSettingsChange={refresh}
          />
        )}
        {page === 'clients' && (
          <ClientsPage clients={clients} onChange={refresh} />
        )}
        {page === 'items' && (
          <ItemsPage items={items} onChange={refresh} />
        )}
        {page === 'settings' && (
          <SettingsPage settings={settings} onChange={refresh} />
        )}
      </main>
    </div>
  )
}
