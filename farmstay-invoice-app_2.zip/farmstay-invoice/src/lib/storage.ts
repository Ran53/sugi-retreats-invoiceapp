import type {
  AppSettings, BusinessProfile, Client, Invoice, Item, Theme, InvoiceSectionToggles
} from '../types'

const KEYS = {
  settings: 'farmstay_settings',
  clients: 'farmstay_clients',
  items: 'farmstay_items',
  invoices: 'farmstay_invoices',
}

const DEFAULT_THEME: Theme = {
  id: 'classic-green',
  name: 'Classic Green',
  primaryColor: '#2d6a4f',
  secondaryColor: '#40916c',
  accentColor: '#ffd60a',
  textColor: '#1a1a1a',
  mutedColor: '#5c6b66',
  backgroundColor: '#ffffff',
  tableHeaderBg: '#2d6a4f',
  fontFamily: 'Inter, system-ui, sans-serif',
  borderRadius: 8,
  logoStyle: 'rounded',
}

const DEFAULT_SECTION_ORDER = [
  'customFields',
  'items',
  'totals',
  'amountInWords',
  'bankDetails',
  'upi',
  'paymentHistory',
  'notes',
]

const DEFAULT_SECTIONS: InvoiceSectionToggles = {
  showLogo: true,
  showCheckInOut: true,
  showGstin: true,
  showAmountInWords: true,
  showBankDetails: false,
  showUpi: false,
  showNotes: true,
  showTerms: true,
  showCustomFields: true,
  showPaymentHistory: false,
}

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

function save<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value))
}

export async function seedIfNeeded() {
  const existingItems = load<Item[]>(KEYS.items, [])
  if (existingItems.length === 0) {
    try {
      const res = await fetch('/data/items.json')
      if (res.ok) {
        const items = await res.json()
        save(KEYS.items, items)
      }
    } catch (e) {
      console.warn('Could not seed items', e)
    }
  }

  const existingSettings = load<AppSettings | null>(KEYS.settings, null)
  if (!existingSettings) {
    try {
      const res = await fetch('/data/business.json')
      const business = res.ok ? await res.json() as BusinessProfile : {
        name: 'SUGI Retreats Farm Stay',
        address: 'Karnataka',
        city: 'Mysore',
        state: 'Karnataka',
        country: 'India',
        phone: '+919945513959',
        email: 'ranjansg3@gmail.com',
      }
      const settings: AppSettings = {
        business,
        invoicePrefix: 'INV-',
        nextInvoiceNumber: 1,
        defaultTaxRate: 0,
        defaultTaxMode: 'none',
        currency: 'INR',
        theme: DEFAULT_THEME,
        sections: DEFAULT_SECTIONS,
        customFieldDefs: [
          { key: 'room', label: 'Room / Cottage', enabled: true },
          { key: 'guests', label: 'No. of Guests', enabled: true },
          { key: 'vehicle', label: 'Vehicle No.', enabled: false },
        ],
        sectionOrder: DEFAULT_SECTION_ORDER,
      }
      save(KEYS.settings, settings)
    } catch (e) {
      console.warn('Could not seed business', e)
    }
  } else {
    // migrate older settings that lack new fields
    const s = existingSettings as any
    if (!s.theme) s.theme = DEFAULT_THEME
    if (!s.sections) s.sections = DEFAULT_SECTIONS
    if (!s.customFieldDefs) {
      s.customFieldDefs = [
        { key: 'room', label: 'Room / Cottage', enabled: true },
        { key: 'guests', label: 'No. of Guests', enabled: true },
        { key: 'vehicle', label: 'Vehicle No.', enabled: false },
      ]
    }
    if (s.defaultTaxMode === undefined) s.defaultTaxMode = 'none'
    if (!s.sectionOrder) s.sectionOrder = DEFAULT_SECTION_ORDER
    save(KEYS.settings, s)
  }
}

export function getSettings(): AppSettings {
  return load<AppSettings>(KEYS.settings, {
    business: {
      name: 'SUGI Retreats Farm Stay',
      address: 'Karnataka',
      city: 'Mysore',
      state: 'Karnataka',
      country: 'India',
      phone: '+919945513959',
      email: 'ranjansg3@gmail.com',
    },
    invoicePrefix: 'INV-',
    nextInvoiceNumber: 1,
    defaultTaxRate: 0,
    defaultTaxMode: 'none',
    currency: 'INR',
    theme: DEFAULT_THEME,
    sections: DEFAULT_SECTIONS,
    customFieldDefs: [
      { key: 'room', label: 'Room / Cottage', enabled: true },
      { key: 'guests', label: 'No. of Guests', enabled: true },
      { key: 'vehicle', label: 'Vehicle No.', enabled: false },
    ],
    sectionOrder: DEFAULT_SECTION_ORDER,
  })
}

export function saveSettings(settings: AppSettings) {
  save(KEYS.settings, settings)
}

export function getClients(): Client[] {
  return load<Client[]>(KEYS.clients, [])
}

export function saveClients(clients: Client[]) {
  save(KEYS.clients, clients)
}

export function upsertClient(client: Client) {
  const clients = getClients()
  const idx = clients.findIndex(c => c.id === client.id)
  if (idx >= 0) clients[idx] = client
  else clients.push(client)
  saveClients(clients)
  return client
}

export function getItems(): Item[] {
  return load<Item[]>(KEYS.items, [])
}

export function saveItems(items: Item[]) {
  save(KEYS.items, items)
}

export function upsertItem(item: Item) {
  const items = getItems()
  const idx = items.findIndex(i => i.id === item.id)
  if (idx >= 0) items[idx] = item
  else items.push(item)
  saveItems(items)
  return item
}

export function getInvoices(): Invoice[] {
  return load<Invoice[]>(KEYS.invoices, [])
}

export function saveInvoices(invoices: Invoice[]) {
  save(KEYS.invoices, invoices)
}

export function upsertInvoice(invoice: Invoice) {
  const invoices = getInvoices()
  const idx = invoices.findIndex(i => i.id === invoice.id)
  if (idx >= 0) invoices[idx] = invoice
  else invoices.unshift(invoice)
  saveInvoices(invoices)
  return invoice
}

export function deleteInvoice(id: string) {
  const invoices = getInvoices().filter(i => i.id !== id)
  saveInvoices(invoices)
}

export function exportAllData() {
  return {
    version: 2,
    exportedAt: new Date().toISOString(),
    settings: getSettings(),
    clients: getClients(),
    items: getItems(),
    invoices: getInvoices(),
  }
}

export function importAllData(data: any) {
  if (data.settings) saveSettings(data.settings)
  if (data.clients) saveClients(data.clients)
  if (data.items) saveItems(data.items)
  if (data.invoices) saveInvoices(data.invoices)
}

export function generateId(prefix = 'id') {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`
}

export function formatCurrency(amount: number, currency = 'INR') {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    maximumFractionDigits: 2,
  }).format(amount)
}

export function numberToWords(num: number): string {
  if (num === 0) return 'Zero Rupees Only'

  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen']
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety']

  function convert(n: number): string {
    if (n < 20) return ones[n]
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '')
    if (n < 1000) return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' and ' + convert(n % 100) : '')
    if (n < 100000) return convert(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 ? ' ' + convert(n % 1000) : '')
    if (n < 10000000) return convert(Math.floor(n / 100000)) + ' Lakh' + (n % 100000 ? ' ' + convert(n % 100000) : '')
    return convert(Math.floor(n / 10000000)) + ' Crore' + (n % 10000000 ? ' ' + convert(n % 10000000) : '')
  }

  const rupees = Math.floor(num)
  const paise = Math.round((num - rupees) * 100)
  let words = 'Indian Rupee ' + convert(rupees)
  if (paise > 0) words += ' and ' + convert(paise) + ' Paise'
  return words + ' Only'
}

export { DEFAULT_THEME, DEFAULT_SECTIONS, DEFAULT_SECTION_ORDER }
