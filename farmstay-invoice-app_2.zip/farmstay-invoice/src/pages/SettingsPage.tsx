import { useState, useRef } from 'react'
import type { AppSettings, Theme, InvoiceSectionToggles } from '../types'
import { saveSettings, exportAllData, importAllData, DEFAULT_THEME, DEFAULT_SECTION_ORDER } from '../lib/storage'

interface Props {
  settings: AppSettings
  onChange: () => void
}

const FONT_OPTIONS = [
  { value: 'Inter, system-ui, sans-serif', label: 'Inter (Modern)' },
  { value: 'Georgia, serif', label: 'Georgia (Classic)' },
  { value: '"Segoe UI", system-ui, sans-serif', label: 'Segoe UI' },
  { value: 'system-ui, -apple-system, sans-serif', label: 'System Default' },
  { value: '"Courier New", monospace', label: 'Courier (Mono)' },
]

const PRESET_THEMES: Theme[] = [
  {
    ...DEFAULT_THEME,
    id: 'classic-green',
    name: 'Classic Green',
    primaryColor: '#2d6a4f',
    tableHeaderBg: '#2d6a4f',
    accentColor: '#ffd60a',
  },
  {
    ...DEFAULT_THEME,
    id: 'ocean-blue',
    name: 'Ocean Blue',
    primaryColor: '#1d4ed8',
    tableHeaderBg: '#1d4ed8',
    secondaryColor: '#3b82f6',
    accentColor: '#93c5fd',
  },
  {
    ...DEFAULT_THEME,
    id: 'warm-earth',
    name: 'Warm Earth',
    primaryColor: '#9a3412',
    tableHeaderBg: '#9a3412',
    secondaryColor: '#c2410c',
    accentColor: '#fdba74',
  },
  {
    ...DEFAULT_THEME,
    id: 'minimal-dark',
    name: 'Minimal Dark',
    primaryColor: '#18181b',
    tableHeaderBg: '#27272a',
    secondaryColor: '#3f3f46',
    accentColor: '#a1a1aa',
    textColor: '#18181b',
  },
]

function Toggle({
  checked,
  onChange,
  label,
  description,
}: {
  checked: boolean
  onChange: (v: boolean) => void
  label: string
  description?: string
}) {
  return (
    <label
      style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '0.85rem',
        padding: '0.85rem 0',
        borderBottom: '1px solid var(--border)',
        cursor: 'pointer',
      }}
    >
      <div
        role="switch"
        aria-checked={checked}
        onClick={e => {
          e.preventDefault()
          onChange(!checked)
        }}
        style={{
          width: 44,
          height: 26,
          borderRadius: 999,
          background: checked ? 'var(--primary)' : '#d1d5db',
          position: 'relative',
          flexShrink: 0,
          transition: 'background 0.2s',
          marginTop: 2,
        }}
      >
        <div
          style={{
            width: 20,
            height: 20,
            borderRadius: '50%',
            background: 'white',
            position: 'absolute',
            top: 3,
            left: checked ? 21 : 3,
            transition: 'left 0.2s',
            boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
          }}
        />
      </div>
      <div>
        <div style={{ fontWeight: 500, fontSize: '0.95rem' }}>{label}</div>
        {description && (
          <div className="text-sm text-muted" style={{ marginTop: 2 }}>
            {description}
          </div>
        )}
      </div>
    </label>
  )
}

export default function SettingsPage({ settings, onChange }: Props) {
  const [biz, setBiz] = useState(settings.business)
  const [prefix, setPrefix] = useState(settings.invoicePrefix)
  const [nextNum, setNextNum] = useState(settings.nextInvoiceNumber)
  const [theme, setTheme] = useState<Theme>(settings.theme || DEFAULT_THEME)
  const [sections, setSections] = useState<InvoiceSectionToggles>(
    settings.sections || {
      showLogo: true,
      showCheckInOut: true,
      showGstin: true,
      showAmountInWords: true,
      showBankDetails: false,
      showUpi: false,
      showNotes: true,
      showTerms: true,
      showCustomFields: true,
      showPaymentHistory: false,
    }
  )
  const [taxMode, setTaxMode] = useState(settings.defaultTaxMode || 'none')
  const [taxRate, setTaxRate] = useState(settings.defaultTaxRate || 0)
  const [customFields, setCustomFields] = useState(
    settings.customFieldDefs || [
      { key: 'room', label: 'Room / Cottage', enabled: true },
      { key: 'guests', label: 'No. of Guests', enabled: true },
      { key: 'vehicle', label: 'Vehicle No.', enabled: false },
    ]
  )
  const [sectionOrder, setSectionOrder] = useState<string[]>(
    settings.sectionOrder || DEFAULT_SECTION_ORDER
  )
  const [dragIndex, setDragIndex] = useState<number | null>(null)
  const [activeTab, setActiveTab] = useState<'brand' | 'theme' | 'sections' | 'tax' | 'data'>('brand')
  const fileRef = useRef<HTMLInputElement>(null)

  const save = () => {
    saveSettings({
      ...settings,
      business: biz,
      invoicePrefix: prefix,
      nextInvoiceNumber: nextNum,
      theme,
      sections,
      defaultTaxMode: taxMode,
      defaultTaxRate: taxRate,
      customFieldDefs: customFields,
      sectionOrder,
    })
    onChange()
    alert('Settings saved')
  }

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 1.5 * 1024 * 1024) {
      alert('Logo is too large. Please use an image under 1.5 MB.')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      setBiz(prev => ({ ...prev, logoUrl: reader.result as string }))
    }
    reader.readAsDataURL(file)
  }

  const removeLogo = () => {
    setBiz(prev => ({ ...prev, logoUrl: undefined }))
    if (fileRef.current) fileRef.current.value = ''
  }

  const applyPreset = (preset: Theme) => {
    setTheme({ ...preset })
  }

  const updateSection = (key: keyof InvoiceSectionToggles, value: boolean) => {
    setSections(prev => ({ ...prev, [key]: value }))
  }

  const handleExport = () => {
    const data = exportAllData()
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `farmstay-invoice-backup-${new Date().toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result as string)
        importAllData(data)
        onChange()
        alert('Data imported successfully.')
      } catch {
        alert('Invalid backup file')
      }
    }
    reader.readAsText(file)
  }

  const tabs = [
    { id: 'brand' as const, label: 'Brand & Logo' },
    { id: 'theme' as const, label: 'Theme' },
    { id: 'sections' as const, label: 'Sections' },
    { id: 'tax' as const, label: 'Tax & GST' },
    { id: 'data' as const, label: 'Data' },
  ]

  return (
    <div>
      <div className="card-header">
        <div>
          <h1>Settings</h1>
          <p className="text-sm text-muted">Customize look, fields & behaviour</p>
        </div>
        <button className="btn btn-primary" onClick={save}>
          Save All Changes
        </button>
      </div>

      {/* Tabs */}
      <div
        className="no-print"
        style={{
          display: 'flex',
          gap: '0.35rem',
          overflowX: 'auto',
          marginBottom: '1.25rem',
          paddingBottom: 4,
        }}
      >
        {tabs.map(t => (
          <button
            key={t.id}
            className={`btn btn-sm ${activeTab === t.id ? 'btn-primary' : 'btn-outline'}`}
            onClick={() => setActiveTab(t.id)}
            style={{ whiteSpace: 'nowrap' }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ========== BRAND ========== */}
      {activeTab === 'brand' && (
        <>
          <div className="card mb-4">
            <h2 className="mb-4">Logo</h2>
            <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center', flexWrap: 'wrap' }}>
              <div
                style={{
                  width: 96,
                  height: 96,
                  borderRadius: theme.logoStyle === 'circle' ? '50%' : theme.borderRadius,
                  border: '1px solid var(--border)',
                  background: '#f8faf9',
                  display: 'grid',
                  placeItems: 'center',
                  overflow: 'hidden',
                  flexShrink: 0,
                }}
              >
                {biz.logoUrl ? (
                  <img src={biz.logoUrl} alt="Logo" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                ) : (
                  <div
                    style={{
                      width: 72,
                      height: 72,
                      background: theme.accentColor,
                      borderRadius: theme.logoStyle === 'circle' ? '50%' : 8,
                      display: 'grid',
                      placeItems: 'center',
                      fontWeight: 800,
                      color: '#1b4332',
                    }}
                  >
                    SUGI
                  </div>
                )}
              </div>
              <div style={{ flex: 1, minWidth: 200 }}>
                <p className="text-sm text-muted mb-2">
                  PNG, JPG or SVG · under 1.5 MB · appears on every invoice
                </p>
                <div className="flex gap-2 flex-wrap">
                  <label className="btn btn-primary" style={{ cursor: 'pointer' }}>
                    {biz.logoUrl ? 'Change Logo' : 'Upload Logo'}
                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/png,image/jpeg,image/jpg,image/svg+xml,image/webp"
                      style={{ display: 'none' }}
                      onChange={handleLogoUpload}
                    />
                  </label>
                  {biz.logoUrl && (
                    <button className="btn btn-outline" onClick={removeLogo}>
                      Remove
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="card mb-4">
            <h2 className="mb-4">Business Profile</h2>
            <div className="form-grid cols-2">
              <div className="field">
                <label>Business Name</label>
                <input value={biz.name} onChange={e => setBiz({ ...biz, name: e.target.value })} />
              </div>
              <div className="field">
                <label>Phone</label>
                <input value={biz.phone} onChange={e => setBiz({ ...biz, phone: e.target.value })} />
              </div>
              <div className="field">
                <label>Email</label>
                <input value={biz.email} onChange={e => setBiz({ ...biz, email: e.target.value })} />
              </div>
              <div className="field">
                <label>City</label>
                <input value={biz.city} onChange={e => setBiz({ ...biz, city: e.target.value })} />
              </div>
              <div className="field">
                <label>Address / State</label>
                <input value={biz.address} onChange={e => setBiz({ ...biz, address: e.target.value })} />
              </div>
              <div className="field">
                <label>GSTIN</label>
                <input value={biz.gstin || ''} onChange={e => setBiz({ ...biz, gstin: e.target.value })} placeholder="29XXXXX..." />
              </div>
              <div className="field">
                <label>UPI ID</label>
                <input value={biz.upiId || ''} onChange={e => setBiz({ ...biz, upiId: e.target.value })} placeholder="name@upi" />
              </div>
              <div className="field">
                <label>Bank Name</label>
                <input value={biz.bankName || ''} onChange={e => setBiz({ ...biz, bankName: e.target.value })} />
              </div>
              <div className="field">
                <label>Account Number</label>
                <input value={biz.accountNumber || ''} onChange={e => setBiz({ ...biz, accountNumber: e.target.value })} />
              </div>
              <div className="field">
                <label>IFSC</label>
                <input value={biz.ifsc || ''} onChange={e => setBiz({ ...biz, ifsc: e.target.value })} />
              </div>
              <div className="field">
                <label>Default Terms</label>
                <input value={biz.defaultTerms || ''} onChange={e => setBiz({ ...biz, defaultTerms: e.target.value })} />
              </div>
              <div className="field">
                <label>Default Notes</label>
                <input value={biz.defaultNotes || ''} onChange={e => setBiz({ ...biz, defaultNotes: e.target.value })} />
              </div>
            </div>
          </div>

          <div className="card mb-4">
            <h2 className="mb-4">Invoice Numbering</h2>
            <div className="form-grid cols-2">
              <div className="field">
                <label>Prefix</label>
                <input value={prefix} onChange={e => setPrefix(e.target.value)} />
              </div>
              <div className="field">
                <label>Next Number</label>
                <input type="number" value={nextNum} onChange={e => setNextNum(Number(e.target.value))} />
              </div>
            </div>
          </div>
        </>
      )}

      {/* ========== THEME ========== */}
      {activeTab === 'theme' && (
        <>
          <div className="card mb-4">
            <h2 className="mb-3">Presets</h2>
            <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
              {PRESET_THEMES.map(p => (
                <button
                  key={p.id}
                  className="btn btn-outline btn-sm"
                  onClick={() => applyPreset(p)}
                  style={{
                    borderColor: theme.id === p.id ? p.primaryColor : undefined,
                    boxShadow: theme.id === p.id ? `0 0 0 2px ${p.primaryColor}` : undefined,
                  }}
                >
                  <span
                    style={{
                      display: 'inline-block',
                      width: 12,
                      height: 12,
                      borderRadius: 3,
                      background: p.primaryColor,
                      marginRight: 6,
                    }}
                  />
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          <div className="card mb-4">
            <h2 className="mb-4">Colors</h2>
            <div className="form-grid cols-2">
              <div className="field">
                <label>Primary (headers, buttons)</label>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <input
                    type="color"
                    value={theme.primaryColor}
                    onChange={e => setTheme({ ...theme, primaryColor: e.target.value, tableHeaderBg: e.target.value })}
                    style={{ width: 48, height: 36, border: 'none', cursor: 'pointer' }}
                  />
                  <input
                    value={theme.primaryColor}
                    onChange={e => setTheme({ ...theme, primaryColor: e.target.value, tableHeaderBg: e.target.value })}
                    style={{ flex: 1 }}
                  />
                </div>
              </div>
              <div className="field">
                <label>Accent (logo fallback)</label>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <input
                    type="color"
                    value={theme.accentColor}
                    onChange={e => setTheme({ ...theme, accentColor: e.target.value })}
                    style={{ width: 48, height: 36, border: 'none', cursor: 'pointer' }}
                  />
                  <input
                    value={theme.accentColor}
                    onChange={e => setTheme({ ...theme, accentColor: e.target.value })}
                    style={{ flex: 1 }}
                  />
                </div>
              </div>
              <div className="field">
                <label>Table Header</label>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <input
                    type="color"
                    value={theme.tableHeaderBg}
                    onChange={e => setTheme({ ...theme, tableHeaderBg: e.target.value })}
                    style={{ width: 48, height: 36, border: 'none', cursor: 'pointer' }}
                  />
                  <input
                    value={theme.tableHeaderBg}
                    onChange={e => setTheme({ ...theme, tableHeaderBg: e.target.value })}
                    style={{ flex: 1 }}
                  />
                </div>
              </div>
              <div className="field">
                <label>Muted text</label>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <input
                    type="color"
                    value={theme.mutedColor}
                    onChange={e => setTheme({ ...theme, mutedColor: e.target.value })}
                    style={{ width: 48, height: 36, border: 'none', cursor: 'pointer' }}
                  />
                  <input
                    value={theme.mutedColor}
                    onChange={e => setTheme({ ...theme, mutedColor: e.target.value })}
                    style={{ flex: 1 }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="card mb-4">
            <h2 className="mb-4">Typography & Shape</h2>
            <div className="form-grid cols-2">
              <div className="field">
                <label>Font Family</label>
                <select
                  value={theme.fontFamily}
                  onChange={e => setTheme({ ...theme, fontFamily: e.target.value })}
                >
                  {FONT_OPTIONS.map(f => (
                    <option key={f.value} value={f.value}>{f.label}</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Logo Style</label>
                <select
                  value={theme.logoStyle}
                  onChange={e => setTheme({ ...theme, logoStyle: e.target.value as Theme['logoStyle'] })}
                >
                  <option value="rounded">Rounded</option>
                  <option value="circle">Circle</option>
                  <option value="square">Square</option>
                </select>
              </div>
              <div className="field">
                <label>Corner Radius ({theme.borderRadius}px)</label>
                <input
                  type="range"
                  min={0}
                  max={20}
                  value={theme.borderRadius}
                  onChange={e => setTheme({ ...theme, borderRadius: Number(e.target.value) })}
                />
              </div>
            </div>
          </div>

          {/* Live mini preview */}
          <div className="card">
            <h2 className="mb-3">Preview</h2>
            <div
              style={{
                border: `1px solid ${theme.primaryColor}33`,
                borderRadius: theme.borderRadius,
                overflow: 'hidden',
                fontFamily: theme.fontFamily,
              }}
            >
              <div style={{ background: theme.tableHeaderBg, color: 'white', padding: '0.6rem 1rem', fontWeight: 600 }}>
                Sample Table Header
              </div>
              <div style={{ padding: '1rem', background: theme.backgroundColor, color: theme.textColor }}>
                <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 8 }}>
                  <div
                    style={{
                      width: 40,
                      height: 40,
                      background: theme.accentColor,
                      borderRadius: theme.logoStyle === 'circle' ? '50%' : theme.borderRadius / 2,
                    }}
                  />
                  <div>
                    <div style={{ fontWeight: 700 }}>{biz.name || 'Your Business'}</div>
                    <div style={{ fontSize: 12, color: theme.mutedColor }}>Sample invoice text</div>
                  </div>
                </div>
                <div style={{ fontSize: 13, color: theme.mutedColor }}>
                  Primary buttons and headers will use this theme across the app.
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* ========== SECTIONS (toggles) ========== */}

      {activeTab === 'sections' && (
        <div className="card">
          <h2 className="mb-2">Invoice Sections</h2>
          <p className="text-sm text-muted mb-4">
            Toggle visibility and drag to reorder how blocks appear on the invoice (below the header).
          </p>

          <Toggle
            label="Logo"
            description="Show business logo in the header"
            checked={sections.showLogo}
            onChange={v => updateSection('showLogo', v)}
          />
          <Toggle
            label="Check-in / Check-out"
            description="Farm-stay dates on the invoice"
            checked={sections.showCheckInOut}
            onChange={v => updateSection('showCheckInOut', v)}
          />
          <Toggle
            label="GSTIN"
            description="Show your GSTIN (and client GSTIN if present)"
            checked={sections.showGstin}
            onChange={v => updateSection('showGstin', v)}
          />
          <Toggle
            label="Terms"
            description="Payment terms next to dates"
            checked={sections.showTerms}
            onChange={v => updateSection('showTerms', v)}
          />

          <h2 className="mt-4 mb-2">Body order (drag to reorder)</h2>
          <p className="text-sm text-muted mb-3">
            Drag the handle ⠿ to change order. Toggle switches control visibility.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {sectionOrder.map((key, index) => {
              const meta: Record<string, { label: string; toggleKey?: keyof typeof sections }> = {
                customFields: { label: 'Custom Fields', toggleKey: 'showCustomFields' },
                items: { label: 'Line Items Table' },
                totals: { label: 'Totals (Subtotal / Tax / Balance)' },
                amountInWords: { label: 'Amount in Words', toggleKey: 'showAmountInWords' },
                bankDetails: { label: 'Bank Details', toggleKey: 'showBankDetails' },
                upi: { label: 'UPI ID', toggleKey: 'showUpi' },
                paymentHistory: { label: 'Payment History', toggleKey: 'showPaymentHistory' },
                notes: { label: 'Notes', toggleKey: 'showNotes' },
              }
              const m = meta[key] || { label: key }
              const enabled = m.toggleKey ? sections[m.toggleKey] : true

              return (
                <div
                  key={key}
                  draggable
                  onDragStart={() => setDragIndex(index)}
                  onDragOver={e => {
                    e.preventDefault()
                  }}
                  onDrop={() => {
                    if (dragIndex === null || dragIndex === index) return
                    const next = [...sectionOrder]
                    const [moved] = next.splice(dragIndex, 1)
                    next.splice(index, 0, moved)
                    setSectionOrder(next)
                    setDragIndex(null)
                  }}
                  onDragEnd={() => setDragIndex(null)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    padding: '0.65rem 0.75rem',
                    background: dragIndex === index ? '#e8f5e9' : '#f8faf9',
                    border: '1px solid var(--border)',
                    borderRadius: 8,
                    cursor: 'grab',
                    opacity: enabled ? 1 : 0.55,
                  }}
                >
                  <span style={{ fontSize: 18, color: '#94a3b8', userSelect: 'none' }}>⠿</span>
                  <div style={{ flex: 1, fontWeight: 500, fontSize: '0.9rem' }}>{m.label}</div>
                  {m.toggleKey ? (
                    <button
                      type="button"
                      className="btn btn-sm"
                      style={{
                        background: enabled ? 'var(--primary)' : '#e5e7eb',
                        color: enabled ? 'white' : '#6b7280',
                        minWidth: 56,
                      }}
                      onClick={e => {
                        e.stopPropagation()
                        updateSection(m.toggleKey!, !enabled)
                      }}
                    >
                      {enabled ? 'On' : 'Off'}
                    </button>
                  ) : (
                    <span className="text-sm text-muted">Always on</span>
                  )}
                </div>
              )
            })}
          </div>

          <button
            className="btn btn-outline btn-sm mt-3"
            onClick={() => setSectionOrder([...DEFAULT_SECTION_ORDER])}
          >
            Reset order
          </button>

          <h2 className="mt-4 mb-2">Custom Fields</h2>
          <p className="text-sm text-muted mb-3">Define extra fields that can appear on invoices.</p>
          {customFields.map((f, idx) => (
            <div key={f.key} className="flex gap-2 items-center mb-2" style={{ flexWrap: 'wrap' }}>
              <input
                value={f.label}
                onChange={e => {
                  const next = [...customFields]
                  next[idx] = { ...f, label: e.target.value }
                  setCustomFields(next)
                }}
                style={{ flex: 1, minWidth: 140 }}
              />
              <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 14 }}>
                <input
                  type="checkbox"
                  checked={f.enabled}
                  onChange={e => {
                    const next = [...customFields]
                    next[idx] = { ...f, enabled: e.target.checked }
                    setCustomFields(next)
                  }}
                />
                Enabled
              </label>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'tax' && (
        <div className="card">
          <h2 className="mb-2">Default Tax / GST</h2>
          <p className="text-sm text-muted mb-4">
            Defaults for new invoices. You can still change tax per invoice later.
          </p>

          <div className="form-grid cols-2 mb-4">
            <div className="field">
              <label>Tax Mode</label>
              <select value={taxMode} onChange={e => setTaxMode(e.target.value as any)}>
                <option value="none">No Tax</option>
                <option value="cgst_sgst">CGST + SGST (Intra-state)</option>
                <option value="igst">IGST (Inter-state)</option>
              </select>
            </div>
            <div className="field">
              <label>Default Rate (%)</label>
              <input
                type="number"
                min={0}
                max={28}
                step={0.5}
                value={taxRate}
                onChange={e => setTaxRate(Number(e.target.value))}
                disabled={taxMode === 'none'}
              />
            </div>
          </div>

          {taxMode === 'cgst_sgst' && (
            <div className="text-sm" style={{ background: '#f1f5f3', padding: '0.75rem 1rem', borderRadius: 8 }}>
              At {taxRate}% → CGST {(taxRate / 2).toFixed(1)}% + SGST {(taxRate / 2).toFixed(1)}%
            </div>
          )}
          {taxMode === 'igst' && (
            <div className="text-sm" style={{ background: '#f1f5f3', padding: '0.75rem 1rem', borderRadius: 8 }}>
              IGST will be charged at {taxRate}%
            </div>
          )}
          {taxMode === 'none' && (
            <div className="text-sm text-muted">
              No tax lines will appear. Suitable if you are not GST-registered or using composition.
            </div>
          )}
        </div>
      )}

      {/* ========== DATA ========== */}
      {activeTab === 'data' && (
        <div className="card">
          <h2 className="mb-2">Backup & Restore</h2>
          <p className="text-sm text-muted mb-4">
            Everything (including logo & theme) is stored in this browser. Export a JSON backup to
            move data to another device or keep a safety copy.
          </p>
          <div className="flex gap-3 flex-wrap">
            <button className="btn btn-outline" onClick={handleExport}>
              Download Backup JSON
            </button>
            <label className="btn btn-outline" style={{ cursor: 'pointer' }}>
              Import Backup
              <input type="file" accept=".json" style={{ display: 'none' }} onChange={handleImport} />
            </label>
          </div>
        </div>
      )}

      <div className="mt-4 no-print">
        <button className="btn btn-primary" onClick={save}>
          Save All Changes
        </button>
      </div>
    </div>
  )
}
