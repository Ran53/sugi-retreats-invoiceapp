export interface BusinessProfile {
  name: string
  tagline?: string
  address: string
  city: string
  state: string
  country: string
  pincode?: string
  phone: string
  email: string
  gstin?: string
  logoUrl?: string
  upiId?: string
  bankName?: string
  accountNumber?: string
  ifsc?: string
  website?: string
  defaultTerms?: string
  defaultNotes?: string
}

export interface Client {
  id: string
  name: string
  email?: string
  phone?: string
  address?: string
  gstin?: string
  notes?: string
  createdAt: string
}

export interface Item {
  id: string
  name: string
  description?: string
  rate: number
  unit?: string
  sacCode?: string
  taxRate?: number
  category?: string
  isActive: boolean
}

export interface InvoiceItem {
  id: string
  itemId?: string
  description: string
  qty: number
  rate: number
  amount: number
  sacCode?: string
  taxRate?: number
  taxable?: boolean
}

export interface Payment {
  id: string
  amount: number
  method: 'cash' | 'upi' | 'bank' | 'card' | 'other'
  date: string
  reference?: string
  notes?: string
}

export type InvoiceStatus = 'draft' | 'sent' | 'partial' | 'paid' | 'overdue' | 'cancelled'

export type TaxMode = 'none' | 'cgst_sgst' | 'igst'

export interface Invoice {
  id: string
  number: string
  status: InvoiceStatus
  clientId?: string
  clientName: string
  clientEmail?: string
  clientPhone?: string
  clientAddress?: string
  clientGstin?: string
  invoiceDate: string
  dueDate: string
  checkIn?: string
  checkOut?: string
  terms?: string
  notes?: string
  items: InvoiceItem[]
  subTotal: number
  discount?: number
  discountType?: 'percent' | 'fixed'
  taxMode?: TaxMode
  taxRate?: number          // e.g. 5 or 18
  cgstAmount?: number
  sgstAmount?: number
  igstAmount?: number
  taxAmount: number
  total: number
  amountInWords: string
  payments: Payment[]
  balanceDue: number
  createdAt: string
  updatedAt: string
  customFields?: Record<string, string>
  // per-invoice visibility overrides (optional)
  showLogo?: boolean
  showCheckInOut?: boolean
  showGstin?: boolean
  showAmountInWords?: boolean
  showBankDetails?: boolean
  showUpi?: boolean
  showNotes?: boolean
  showTerms?: boolean
}

export interface Theme {
  id: string
  name: string
  primaryColor: string      // main brand / table header
  secondaryColor: string    // accents
  accentColor: string       // logo circle / highlights
  textColor: string
  mutedColor: string
  backgroundColor: string
  tableHeaderBg: string
  fontFamily: string
  borderRadius: number      // px
  logoStyle: 'circle' | 'rounded' | 'square'
}

export interface InvoiceSectionToggles {
  showLogo: boolean
  showCheckInOut: boolean
  showGstin: boolean
  showAmountInWords: boolean
  showBankDetails: boolean
  showUpi: boolean
  showNotes: boolean
  showTerms: boolean
  showCustomFields: boolean
  showPaymentHistory: boolean
}

export interface AppSettings {
  business: BusinessProfile
  invoicePrefix: string
  nextInvoiceNumber: number
  defaultTaxRate: number
  defaultTaxMode: TaxMode
  currency: string
  theme: Theme
  sections: InvoiceSectionToggles
  customFieldDefs: { key: string; label: string; enabled: boolean }[]
}
